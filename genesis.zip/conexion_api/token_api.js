const TOKEN = 'VdhnZ3itZ5Ycg1G8Tmk7PkGPu3iclc6RjTF1M908-583';
const PROTOCOLO = 'https';
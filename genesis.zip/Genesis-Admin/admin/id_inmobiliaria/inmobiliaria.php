<?php 
    $id_inmobiliaria = 7;
?>

<meta charset="UTF-8"/>

<!-- Colocar aqui el nombre de la pagina que aparecera en la ventana del navegador, despues de la etiqueta php -->
<title><?php if($page != ""){echo $page.' | ';}?>G.A. Inmobiliaria - Bogotá</title>

<!-- Colocar una breve descripcion de la empresa -->
<meta name="description" content="Nuestro curriculum habla cerca de varios años en donde hemos podido enfocar las necesidades de nuestros clientes que día a día se convierten en retos para nosotros. Retos muy gratos de resolver.">

<!-- Palabras clave, sobre la Inmobiliaria para la busqueda, casi no se usa pero los clientes pueden pedirlas colocar maximo 4 -->
<meta name="keywords" content="
    Inmobiliarias Bogotá,
	Soluciones Inmobiliarias, 
	Apartamentos para arrendar en Bogotá	
	Inmobiliaria Genesis,
    ">

<!-- Creador de la pagina. -->
<meta name="author" content="Dexcon Digital">

<!-- Como manejamos conexion con API siempre definir el dominio principal -->
<link rel="canonical" href="https://www.gainmobiliariasas.com"/>

<!--  ***************** Datos  ****************+ -->

<!-- definir qe tipo de aplicacion es; defecto website-->
<meta property="og:type" content="website" />
<!-- Nombre de la empresa o pagina -->
<meta property="og:title" content="G.A. Inmobiliaria"/>

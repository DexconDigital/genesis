<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="css/swiper.min.css">   
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/all.min.css">
<link rel="stylesheet" href="css/mdb.css">
<link rel="stylesheet" href="css/mdb.lite.css">
<link rel="stylesheet" href="css/mdb.lite.min.css">
<link rel="stylesheet" href="css/mdb.min.css">
<link rel="stylesheet" href="css/style.css">

<?php 
    $url_host = 'PROTOCOLO://'.$_SERVER["HTTP_HOST"].'//';
    // $url_host = 'https://'.$_SERVER["HTTP_HOST"].'/';
    $url_total = 'PROTOCOLO://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

    define('TOKEN', 'VdhnZ3itZ5Ycg1G8Tmk7PkGPu3iclc6RjTF1M908-583');

    define('PROTOCOLO', 'https' );

?>